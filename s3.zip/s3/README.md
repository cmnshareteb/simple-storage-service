you need following node modules

fs,multer,file-encrypt

run: npm run dev
Browser: localhost

mlab: 
username: cmnshareteb
password: cmnshareteb1
go to s3 database
