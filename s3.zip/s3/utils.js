//This file contains common utility functions which can be used directly in app 
onst secureRandom = require('secure-random');

class utils
{
	
	//generates random 32bit hex string
	static generateKey()
	{
	return secureRandom.randomBuffer(32).toString('hex');
	}
}

module.exports = utils;
