var express = require('express');
var bodyParser = require('body-parser');
var mongoose = require('mongoose');
var ObjectId = require('mongodb').ObjectId; 

var emailValidator = require("email-validator");
var passwordValidator = require('password-validator');
const bcrypt = require('bcryptjs');
const saltRounds = 10;


var passport = require('passport');
var CustomStrategy = require('passport-custom');


var multer = require('multer');
const storage = multer.diskStorage({
  destination:function(req,file,cb){
    cb(null,'uploads');
  },
  filename: function(req,file,cb) {
    cb(null,new Date().toISOString().replace(/:/g, '-') + file.originalname);
  }
});
var upload = multer({storage:storage});


var fs = require('fs');       
var encryptor = require('file-encryptor');


var Utils=require('./utils');
const {PWD_SCHEMA,PHNUMBER_SCHEMA,PASSPHRASE_SCHEMA,NAME_SCHEMA,STORE,userModel,UPLOAD_PATH} = require('./config');

mongoose.set('useFindAndModify', false);


/*
//add data to mongodb
var user1 = userModel({name:'pkw',email:'pkw@pkw.com',phnumber:'7066506779',password:'pkw'}).save(function(err){
  if(err) throw err;
  console.log('user added.');
});
*/


//params
var loginErrors = new Object();



var app = express();
app.set('view engine','ejs');
app.use('/assets',express.static('assets'));
app.use('/downloads',express.static('downloads'));
app.use('/uploads',express.static('uploads'));
app.use(require('express-session')({
  secret: 'kjhasdkjhkasdk',
  store: STORE,
  resave: false,
  saveUninitialized: false,
  cookie: {
    maxAge: 1000 * 60 * 60 * 24 * 7 // cookie age: 1 week
  }
  //cookie: { secure: true }
}));
app.use(passport.initialize());
app.use(passport.session());
var urlencodedParser = bodyParser.urlencoded({extended:false});

app.use(function(req,res,next){
  res.locals.isAuthenticated = req.isAuthenticated();
  res.locals.isUser = req.user;
  next();
});

app.get('/', function(req,res) {
  res.render('home',{});
});

app.get('/home', function(req,res) {
  res.render('home',{});
});

app.get('/about', function(req,res) {
  res.render('about',{});
});

//__________________________________LOGIN RELATED ROUTINES________________________________________

//use passport js for password validation.
passport.use(new CustomStrategy(
  function(req, done) {
    userModel.find({email:req.body.email},function(err,data){
      if(err) throw err;

      if(data.length === 0 || data.length >1 ) {
        console.log('zero or more than 1 user with same email!');
        return done(null,false);
      }

      bcrypt.compare(req.body.pwd,data[0].password,function(err,response){
        if(response === true) {
          req.login(data[0]._id,function(err) {
            return done(null, data[0]._id);
          });
        }
        else {
          loginErrors.success = false;
          //console.log('password do not match! invalid!');
          return done(null,false);
        }
      });
  }
)}));


//simple login page rendering
app.get('/login', function(req,res) {
  console.log(req.user);
  console.log(req.isAuthenticated());
  res.render('login',{errors:loginErrors});
});

//when user enters login data, it is parsed here
app.post('/login',urlencodedParser,passport.authenticate('custom',
{ failureRedirect: '/login' }),
  function(req, res) {
    res.redirect('/upload');
  }
);

//____________________________________LOGOUT RELATED ROUTINES _____________________________________
//it simply removes session & user gets logged out
app.get('/logout',function(req,res) {
  req.logout();
  req.session.destroy();
  res.redirect('/');
});

//_______________________________________SIGN-UP RELATED ROUTINES____________________________________
app.get('/register', function(req,res) {
  var error = new Object();
  res.render('register',{errors:error});
});

app.post('/register',urlencodedParser,function(req,res){
  registerUser(req.body.name,req.body.phnumber,req.body.email,req.body.pwd,req.body.pwd2,function(err,error){
  if(err)
    console.log('Error while register user : ',err);
  res.render('register',{errors: error});
  });
});



//      _____________________________________FILE BOOK RELATED ROUTINES_________________

//default landing page , show form for entry addition
// shows all previous entries
app.get('/upload', function(req,res) {
  userModel.findOne({"_id":new ObjectId(req.user)},function(err,userProfile) {
  if(err) throw err;
    var fileData = new Object();
    fileData.data = userProfile.filebook;
    res.render('upload',{fileData:fileData});
  });
});


//upload file,encrypt it, save details in DB, delete unencrypted file
app.post('/upload',upload.single('myfile'), function(req,res,next) {
    
  console.log(req.file);
  var key = Utils.generateKey();
  encryptor.encryptFile('uploads/'+req.file.filename, 'uploads/'+req.file.filename+'.dat', key, function(err) {
                  // Encryption complete.remove original file
                   fs.unlink('uploads/'+req.file.filename,function(err){
                    if (err) 
                      console.log('error while removing file!',err);
                    // add entry in DB
                    userModel.findOneAndUpdate({"_id":new ObjectId(req.user)},{$push: {filebook: {filename: req.file.filename+'.dat', originalname: req.file.originalname,key:key}}},
                      {new: true},(err,doc) => {
                        if(err)
                          console.log('Error while updating database!',err);
                        var fileData = new Object();
                        fileData.success = true;
                        fileData.data = doc.filebook;
                        res.render('upload',{fileData:fileData});
                    });
     });
  });
});

//_____________________________________ DOWNLOAD RELATED ROUTINES  _____________________________________



app.get('/download', function(req,res) {
  encryptor.decryptFile('uploads/'+req.query.filename, 'downloads/'+req.query.originalname, req.query.key, function(err) {
      var fileData = new Object();
      fileData.name = req.query.originalname;
      fileData.link = 'downloads/'+req.query.originalname;
      fileData.success = true;
      res.render('download',{fileData:fileData});
  });
    
});



//_________________________________________________SERVICE ROUTINES___________________________________________
app.listen(80,function(){
         console.log(' Server started at 80');
});

passport.serializeUser(function(user_id, done) {
  done(null, user_id);
});

passport.deserializeUser(function(user_id, done) {
    done(null, user_id);
});

function authenticationMiddleware () {
	return (req, res, next) => {
		console.log(`req.session.passport.user: ${JSON.stringify(req.session.passport)}`);

	    if (req.isAuthenticated()) return next();
	    res.redirect('/login')
	}
}

//backend calls

function registerUser(name,phnumber,email,pwd1,pwd2,cb)
{
  var error = new Object();
  //validate 
  var isNameOk  = NAME_SCHEMA.validate(name);
  var isPhnumberOk = PHNUMBER_SCHEMA.validate(phnumber);
  var isEmailOk  = emailValidator.validate(email);
  var isPwdOK  = PWD_SCHEMA.validate(pwd1);
  
  
  var isPwd2Ok;
  if(pwd1 === pwd2)
    isPwd2Ok = true;
  else
    isPwd2Ok = false;

  if(!isNameOk)
    error.names =true;
  if(!isPhnumberOk)
    error.phone = true;
  if(!isEmailOk)
    error.email = true;
  if(!isPwdOK)
    error.password = true;
  if(!isPwd2Ok)
    error.password2 = true;

  var isExistsOk=false;
  
  userModel.find({email:email},function(err,data){
      if(err) throw err;

      if(data.length === 0 || data.length >1 )
       {
        error.exists = true;
        exval=true;
       }
   });

  if( (isNameOk && isPhnumberOk && isEmailOk && isPwdOK && isPwd2Ok=== true) && (isExistsOk === false) )
  {
    bcrypt.hash(pwd1, saltRounds, function(err, hash) {
    // Store hash in your password DB.
    var userEntry = userModel({name:name,phnumber:phnumber,email:email ,password:hash})
  .save(function(err){
      if(err) throw err;
      });
    });
    error.success = true;
   }
   else
   {
     error.success= false;
   }
   
   cb(null,error);
}

